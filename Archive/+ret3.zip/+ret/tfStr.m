function s = tfStr(tf)
if tf, s = 'YES'; else, s = 'NO'; end
end
